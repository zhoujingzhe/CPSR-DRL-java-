package Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
class Node 
{
	public Node()
	{}
	
    public int val;
    public int key;
}
class Test {
	public static void main(String[] args)
	{
		int[] nums = new int[] {1,1,1,2,2,3};
		topKFrequent(nums, 2);
	}

    public static List<Integer> topKFrequent(int[] nums, int k) {
        Map<Integer, Integer> m = new HashMap<Integer, Integer> ();
        for (int i = 0; i < nums.length; i++)
        {
            if (m.containsKey(nums[i]))
            {
                m.put (nums[i], m.get(nums[i]) + 1);
            }
            else
            {
                m.put(nums[i], 1);
            }
        }
        Node[] out = new Node[k];
        for (Integer key:m.keySet())
        {
            int key1 = key;
            int val = m.get(key);
            for (int l = 0; l < k; l++)
            {
                if (out[l] == null)
                {
                    System.out.println("In");
                    Node t = new Node();
                    t.val = val;
                    t.key = key1;
                    out[l] = t;
                    break;
                }
                else
                {
                    if (out[l].val < val)
                    {
                        int tmp1 = out[l].val;
                        out[l].val = val;
                        val = tmp1;
                        int tmp2 = out[l].key;
                        out[l].key = key1;
                        key1 = tmp2;
                    }
                }
            }
        }
        List<Integer> out1 = new ArrayList<Integer>();
        for (Node t: out)
        {
            out1.add(t.key);
        }
        return out1;
    }

}