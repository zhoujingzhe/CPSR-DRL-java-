package Test;
import java.lang.instrument.Instrumentation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.jblas.DoubleMatrix;

import jparfor.Functor;
import jparfor.MultiThreader;
import jparfor.Range;
public class Test2 {
	public Test2(int[] intarray)
	{
		this.intarray = intarray;
	}
	int[] intarray = null;

	public void remove()
	{
		this.intarray = null;
	}
	public static void main(String[] args)
	{
		double[] b = {0.333333333333, 0.333333333333, 0.333333333333, 0.0, 0.0, 0.0};
		double[][] T = new double[6][6];
		T[0][0] = 1.0;
		T[1][1] = 1.0;
		T[2][2] = 1.0;
		T[3][3] = 1.0;
		T[4][4] = 1.0;
		T[5][5] = 1.0;
		
		double[][] O = new double[6][6];
		O[0][0] = 0.75;
		O[1][1] = 0.1;
		O[2][2] = 0.1;
		O[3][3] = 0.0;
		O[4][4] = 0.0;
		O[5][5] = 0.0;
		DoubleMatrix b_h = new DoubleMatrix(b);
		DoubleMatrix T_Mat = new DoubleMatrix(T);
		DoubleMatrix O_Mat = new DoubleMatrix(O);
		
		DoubleMatrix numerator = b_h.transpose().mmul(O_Mat);
		DoubleMatrix denumerator = numerator.mmul(DoubleMatrix.ones(6));
		DoubleMatrix a = numerator.mul(1/denumerator.get(0,  0));
		System.out.println();
	}
}