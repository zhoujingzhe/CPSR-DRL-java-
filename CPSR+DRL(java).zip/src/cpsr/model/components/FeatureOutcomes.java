package cpsr.model.components;

import java.util.ArrayList;

import cpsr.environment.components.Action;

public class FeatureOutcomes {
	public ArrayList<PredictionVector> PredVectors;
	public ArrayList<Double> rewardset;
	public ArrayList<Action> Action;
	public int index = -1;

}
