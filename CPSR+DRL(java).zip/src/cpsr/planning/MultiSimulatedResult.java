package cpsr.planning;

import cpsr.environment.TrainingDataSet;

public class MultiSimulatedResult {
	public TrainingDataSet TList;
	public int index = -1;
}
